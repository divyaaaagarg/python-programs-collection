# GitHub Projects Bundle — Start Here

This bundle contains five self-contained starter repositories for the portfolio assignment.

## Included folders
1. `01-python-programs-collection`
2. `02-messy-python-code-improvement`
3. `03-bug-fixing-using-cursor-ai`
4. `04-interactive-quiz-application`
5. `05-book-reading-list-application`

## Important before submission
- Review and understand each project; personalize it to reflect work you can explain.
- Each folder is intended to become its own GitHub repository. Create a repository on GitHub, then upload the contents of that folder (not the whole bundle folder) to that repository.
- Update the Book Reading List README with its real deployed URL after deployment. Do not leave `ADD_YOUR_DEPLOYED_URL_HERE` as if it were a real link.
- Add actual live URLs to the Quiz and Book projects after deploying them.
- The Cursor AI project documents an example debugging exercise. If the assignment expects proof of your own Cursor workflow, open it in Cursor and record the prompts and changes you actually used.
- These projects do not include the final portfolio website or API chatbot; those are the main assignment to be built by Claude from your assignment PDF.
